---
marp: true
theme: gaia
class: invert
---

# Mejores actuaciones de Chiara Oliver 

#### Natalia Coronado

![bg width: 400px height:400px](singleChiara.png)

---

# -----------  Top 5: The Climb ----------

![bg width: 400px height:400px](theclimb.png)


---

# ---- Top 4: Walk Like An Egyptian ----

![bg width: 400px height:400px](walkLike.png)


---

# ----------- Top 3: Escriurem -----------

![bg width: 400px height:400px](escriurem.png)




---

# ------- Top 2: You Oughta Know -------

![bg width: 400px height:400px](youOughta.png)

---

# -------- Top 1: I Kissed A Girl --------

![bg width: 400px height:400px](iKissed.png)





